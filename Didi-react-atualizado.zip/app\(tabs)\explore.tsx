import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const SegundoAno = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conteúdo do 2º Ano</Text>
      {/* Imagem removida conforme solicitado */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e8f5e9', // Verde bem claro
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2e7d32',
  },
});

export default SegundoAno;