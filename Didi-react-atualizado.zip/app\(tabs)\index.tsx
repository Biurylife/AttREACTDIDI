import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const PrimeiroAno = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conteúdo do 1º Ano</Text>
      {/* Imagem removida conforme solicitado */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e3f2fd', // Azul bem claro
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1565c0',
  },
});

export default PrimeiroAno;