import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const TerceiroAno = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Conteúdo do 3º Ano</Text>
      {/* Imagem removida conforme solicitado */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff3e0', // Laranja bem claro
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ef6c00',
  },
});

export default TerceiroAno;